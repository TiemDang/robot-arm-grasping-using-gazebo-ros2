import meshio
mesh = meshio.read("/home/noa/ros2_ws/src/my_robot/meshes/fixed_base.STL")
meshio.write("fixed_base_2.STL", mesh, file_format="stl", binary=False)
